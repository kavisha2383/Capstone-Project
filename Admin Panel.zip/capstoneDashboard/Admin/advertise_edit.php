<?php include ('dbconfig/dbconfig.php'); ?>
<?php include ('includes/header.php'); ?>



<div class="container-fluid">
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-lg-6 mb-lg-0 mb-4">

        </div>
        <div class="col-lg-6">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end">

            </ul>
        </div>
    </div>


    <div class="card mt-3">

        <div class="card-header">
            <h4>Edit Advertise</h4>
        </div>

        <?php

        $id = $_GET['id'];
        $fetch_query = "SELECT * FROM advertisement WHERE ad_id='$id'";
        $fetch_query_run = mysqli_query($connection, $fetch_query);

        if ($fetch_query_run) {
            foreach ($fetch_query_run as $row) {
                //;
                ?>

                <div class="card-body">

                    <form action="code.php" method="POST" enctype="multipart/form-data">

                        <div class="mb-3">
                            <label for="ad_id" class="text-secondary">Edit Category Id</label>
                            <input type="text" class="form-control " name="id" id="id" value="<?php echo $row['ad_id']; ?>"
                                placeholder="Add Advertise" required readonly>
                        </div>

                        <div class="mb-3">
                            <label for="banner" class="text-secondary">Edit Banner</label>
                            <input class="form-control form-control-sm fs-5" name="banner" id="banner"
                                value="<?php echo $row['banner']; ?>" accept="image/jpg, image/jpeg, image/png" type="file"
                                type="file" required>
                        </div>

                        <div class="mb-3">
                            <label for="title" class="text-secondary">Edit Title</label>
                            <input type="text" class="form-control" name="title" id="title" value="<?php echo $row['title']; ?>"
                             required>
                        </div>

                        <div class="mb-3">
                            <label for="title" class="text-secondary">Edit Description</label>
                            <input type="text" class="form-control" name="description" id="description" value="<?php echo $row['description']; ?>"
                             required>
                        </div>


                        <div class="card-footer">
                            <button type="submit" name="ad_update_btn" class="btn btn-primary float-start mt-4"
                                data-bs-dismiss="modal">UPDATE</button>
                        </div>

                        <a href="advertise.php" button type="submit" name="btn_cancel"
                            class="btn btn-danger float-end">CANCEL</button>
                            <a href="<?= $previous ?>"></a>
                    </form>
                </div>
                <?php
            }
        } else {
            echo "No record found";
        }

        ?>


    </div>

</div>




<?php include ('includes/footer.php'); ?>