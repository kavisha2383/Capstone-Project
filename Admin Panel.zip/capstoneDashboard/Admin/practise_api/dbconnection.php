<?php
function dbconnection()
{
    $con=mysqli_connect("localhost","root","","capstone");
    return $con;
}
?>