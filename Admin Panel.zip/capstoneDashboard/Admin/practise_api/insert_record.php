<?php

include("dbconnection.php");
$con = dbconnection();

if(isset($_POST['firstname']))
{
    $firstname=$_POST['firstname'];
}
else return;

if(isset($_POST['lastname']))
{
    $lastname=$_POST['lastname'];
}
else return;

if(isset($_POST['email']))
{
    $email=$_POST['email'];
}
else return;

if(isset($_POST['contact']))
{
    $contact=$_POST['contact'];
}
else return;

if(isset($_POST['add1']))
{
    $add1=$_POST['add1'];
}
else return;

if(isset($_POST['add2']))
{
    $add2=$_POST['add2'];
}
else return;

if(isset($_POST['city']))
{
    $city=$_POST['city'];
}
else return;

if(isset($_POST['state']))
{
    $state=$_POST['state'];
}
else return;

if(isset($_POST['pincode']))
{
    $pincode=$_POST['pincode'];
}
else return;

if(isset($_POST['pass']))
{
    $pass=$_POST['pass'];
}
else return;

$query="INSERT INTO `customer`(`firstname`, `lastname`, `email`, `contact`, `add1`, `add2`, `city`, `state`, `pincode`, `pass`) 
VALUES ('$firstname','$lastname','$email','$contact','$add1','$add2','$city','$state','$pincode','$pass')";

$exe = mysqli_query($con, $query);

$arr=[];
if($exe)
{
    $arr["success"]="true";
}
else
{
    $arr["success"]="false";
}
print(json_encode($arr));

?>