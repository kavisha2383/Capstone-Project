<?php include ('includes/header.php'); ?>
<?php include ('dbconfig/dbconfig.php'); ?>



<div class="container-fluid">
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-lg-6 mb-lg-0 mb-4">

        </div>
        <div class="col-lg-6">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end">

            </ul>
        </div>
    </div>


    <div class="card mt-3">
        <div class="card-header">
            <h4>Add Advertisement</h4>
        </div>

        <div class="card-body">

            <form action="code.php" method="POST" enctype="multipart/form-data">
                <div class="card-body">

                    
                    <div class="mb-3">
                        <label for="" class="text-secondary">Add Banner</label>
                        <input class="form-control form-control-sm fs-5" name="banner"
                            accept="image/jpg, image/jpeg, image/png" type="file" required>
                    </div>

                    <div class="mb-3">
                        <label for="" class="text-secondary">Add Title</label>
                        <input type="text" class="form-control" name="title" required>
                    </div>

                    <div class="mb-3">
                        <label for="" class="text-secondary">Add Description</label>
                        <textarea rows="4" cols="50" placeholder="typing here.." class="form-control" name="description" required></textarea>
                    </div>

                    <div class="card-footer">
                        <input type="submit" name="save_ad" class="btn btn-primary float-start mt-4"
                            data-bs-dismiss="modal">
                    </div>

                    <a href="advertise.php" button type="submit" name="btn_cancel"
                        class="btn btn-danger float-end">CANCEL</button>
                        <a href="<?= $previous ?>"></a>
            </form>
        </div>
    </div>

</div>




<?php include ('includes/footer.php'); ?>