<footer class="footer pt-5">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">

            </div>
            <div class="col-lg-6">
                <ul class="nav nav-footer justify-content-center justify-content-lg-end">


                </ul>
            </div>
        </div>
    </div>
</footer>


<script src="assets/js/bootstrap.bundle.min.js"></script>
<!--sweet alert-->
<script src="assets/js/sweetalert.js"></script>
<!--alerify js-->
<script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

</main>


<!--
<?php
if (isset ($_SESSION['status']) && $_SESSION['status'] != '') {
    
    ?>
    <script>
        swal({
            title: '<?php echo $_SESSION['status']; ?>',
            icon: '<?php echo $_SESSION['status_code']; ?>',
            button: "okeyy!",
        });
    </script>
    
    <?php
    //unset($_SESSION['status']);
}
?>-->

<?php
if (isset ($_SESSION['status']) && $_SESSION['status'] !='') {
    
    ?>
    <script>
        alertify.set('notifier','position', 'top-center');
        alertify.success('<?php echo $_SESSION['status']; ?>');
    </script>
    
    <?php
    unset($_SESSION['status']);
}

?>






</body>

</html>