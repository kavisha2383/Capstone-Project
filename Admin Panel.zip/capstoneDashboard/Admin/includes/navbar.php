<nav class="navbar navbar-main navbar-bg navbar-expand-lg shadow-none border-radius-xl">
    <div class="container-fluid py-1 px-3">
        <h4 class="text-light fw-bold">MY GROCERY</h4>
    </div>
</nav>