<?php include ('includes/header.php'); ?>
<?php include ('dbconfig/dbconfig.php'); ?>



<div class="container-fluid">
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-lg-6 mb-lg-0 mb-4">

        </div>
        <div class="col-lg-6">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end">

            </ul>
        </div>
    </div>


    <div class="card mt-3">
        <div class="card-header">
            <h4>Add Offer</h4>
        </div>

        <div class="card-body">

            <form action="code.php" method="POST" enctype="multipart/form-data">
                <div class="card-body">

                    <div class="mb-3">
                        <label>Select Product</label>
                        <?php
                        $query = "SELECT * FROM product";
                        $query_run = mysqli_query($connection, $query);
                        if (mysqli_num_rows($query_run) > 0) {
                            ?>
                            <select name="prod_id" class="form-control">
                                <?php
                                foreach ($query_run as $item) { ?>
                                    <option value="<?= $item['prod_id'] ?>"><?= $item['prod_name'] ?></option>
                                <?php }
                                ?>
                            </select>

                            <?php
                        }

                        ?>
                    </div>

                    <div class="mb-3">
                        <label for="" class="text-secondary">Add Offer</label>
                        <input type="text" class="form-control" name="offer_name" required>
                    </div>

                    <div class="mb-3">
                        <label for="" class="text-secondary">Add offer Image</label>
                        <input class="form-control form-control-sm fs-5" name="offer_image"
                            accept="image/jpg, image/jpeg, image/png" type="file" required>
                    </div>

                    <div class="mb-3">
                        <label for="" class="text-secondary">Add Offer Quantity</label>
                        <input type="text" class="form-control" name="offer_quantity" required>
                    </div>

                    <div class="mb-3">
                        <label for="" class="text-secondary">Add Offer Price</label>
                        <input type="text" class="form-control" name="offer_price" required>
                    </div>

                    <div class="mb-3">
                        <label for="" class="text-secondary">Add Discount</label>
                        <input type="text" class="form-control" name="disc_amt" required>
                    </div>
                    <div class="mb-3">
                        <label for="" class="text-secondary"> Start Date</label>
                        <input type="date" class="form-control" name="start_date" required>
                    </div>

                    <div class="mb-3">
                        <label for="" class="text-secondary">End Date</label>
                        <input type="date" class="form-control" name="end_date" required>
                    </div>
                </div>


                <div class="card-footer">
                    <input type="submit" name="save_offer" class="btn btn-primary float-start mt-4"
                        data-bs-dismiss="modal">
                </div>

                <a href="offers.php" button type="submit" name="btn_cancel"
                    class="btn btn-danger float-end">CANCEL</button>
                    <a href="<?= $previous ?>"></a>
            </form>
        </div>
    </div>

</div>




<?php include ('includes/footer.php'); ?>