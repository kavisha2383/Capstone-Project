<?php include ('dbconfig/dbconfig.php'); ?>
<?php include ('includes/header.php'); ?>



<div class="container-fluid">
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-lg-6 mb-lg-0 mb-4">

        </div>
        <div class="col-lg-6">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end">

            </ul>
        </div>
    </div>


    <div class="card mt-3">

        <div class="card-header">
            <h4>Edit Category</h4>
        </div>

        <?php

        $id = $_GET['id'];
        $fetch_query = "SELECT * FROM category WHERE cat_id='$id'";
        $fetch_query_run = mysqli_query($connection, $fetch_query);

        if ($fetch_query_run) {
            foreach ($fetch_query_run as $row) {
                //;
                ?>

                <div class="card-body">

                    <form action="code.php" method="POST" enctype="multipart/form-data">

                        <div class="mb-3">
                            <label for="id" class="text-secondary">Edit Category Id</label>
                            <input type="text" class="form-control " name="id" id="id" value="<?php echo $row['cat_id']; ?>"
                                placeholder="Add Product" required readonly>
                        </div>

                        <div class="mb-3">
                            <label for="cat_name" class="text-secondary">Edit Category Name</label>
                            <input type="text" class="form-control" name="cat_name" id="cat_name" value="<?php echo $row['cat_name']; ?>"
                             required>
                        </div>

                        <div class="mb-3">
                            <label for="cat_image" class="text-secondary">Edit product Image</label>
                            <input class="form-control form-control-sm fs-5" name="cat_image" accept="image/jpg, image/jpeg, image/png" type="file" required>
                            <input type="hidden" name="cat_image_old" value="<?php echo $row['cat_image']; ?>" >
                            <img src="<?php echo "uploads/".$row['cat_image']; ?>" width="75" height="75" alt="image">
                        </div>

                        <div class="card-footer">
                            <button type="submit" name="cat_update_btn" class="btn btn-primary float-start mt-4"
                                data-bs-dismiss="modal">UPDATE</button>
                        </div>

                        <a href="categories.php" button type="submit" name="btn_cancel"
                            class="btn btn-danger float-end">CANCEL</button>
                            <a href="<?= $previous ?>"></a>
                    </form>
                </div>
                <?php
            }
        } else {
            echo "No record found";
        }

        ?>


    </div>

</div>




<?php include ('includes/footer.php'); ?>