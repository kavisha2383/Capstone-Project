<?php include('includes/header.php'); ?>

<main class="mt-1 pt-2 py-5">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3 mb-3">
        <div class="card card-1 bg-dark text-white h-100">
          <div class="card-body py-5 fw-bold">Total Products <h4 class="mt-1 ms-0 text-white">45</h4></div>
          <div class="card-footer d-flex">
            View Details
            <span class="ms-auto">
              <i class="bi bi-chevron-right"></i>
            </span>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-3">
        <div class="card card-2 bg-dark text-white h-100">
          <div class="card-body py-5 fw-bold">Total Categories <h4 class="mb-1 ms-0 text-white">45</h4></div>
          <div class="card-footer d-flex">
            View Details
            <span class="ms-auto">
              <i class="bi bi-chevron-right"></i>
            </span>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-3">
        <div class="card card-3 bg-dark text-white h-100">
          <div class="card-body py-5 fw-bold">Total Orders <h4 class="mb-0 ms-1 text-white">45</h4></div>
          <div class="card-footer d-flex">
            View Details
            <span class="ms-auto">
              <i class="bi bi-chevron-right"></i>
            </span>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-3">
        <div class="card card-4 bg-dark text-white h-100">
          <div class="card-body py-5 fw-bold">Total Users <h4 class="mb-0 ms-1 text-white">45</h4></div>
          <div class="card-footer d-flex">
            View Details
            <span class="ms-auto">
              <i class="bi bi-chevron-right"></i>
            </span>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6 mb-3">
        <div class="card h-100">
          <div class="card-header">
            <span class="me-2"><i class="bi bi-bar-chart-fill"></i></span>
            Monthly Orders
          </div>
          <div class="card-body">
            <canvas class="chart" width="400" height="200"></canvas>
          </div>
        </div>
      </div>
      <div class="col-md-6 mb-3">
        <div class="card h-100">
          <div class="card-header">
            <span class="me-2"><i class="bi bi-bar-chart-fill"></i></span>
            Sales Report
          </div>
          <div class="card-body">
            <canvas class="chart" width="400" height="200"></canvas>
          </div>
        </div>
      </div>
    </div>
</main>

<?php include('includes/footer.php'); ?>