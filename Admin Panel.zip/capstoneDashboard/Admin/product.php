<?php include ('dbconfig/dbconfig.php'); ?>
<?php include ('includes/header.php'); ?>



<div class="container-fluid">
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-lg-6 mb-lg-0 mb-4">

        </div>
        <div class="col-lg-6">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end">
                <a href="insert.php" class="btn btn-primary text-white float-end mt-4"><i class="bi bi-bag-plus"></i>
                    Add Product
                </a>
            </ul>
        </div>
    </div>

    <!-- <?php

    if (isset ($_SESSION['status']) && $_SESSION['status'] != '') {

        ?>
        <div class="alert alert-success text-light alert-dismissible fade show mt-1" role="alert">
            <strong>heyy!</strong> <?php echo $_SESSION['status']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
        <?php
        //unset($_SESSION['status']);
    }
    ?> -->



    <div class="card mt-3">
        <div class="card-header">
            <h4>Product Table</h4>
        </div>

        <div class="card-body pt-4 text-center">
            <div class="table-responsive">
                <table class="table table-striped datatable fs-6" style="width:100%" id="datatable" width="100%"
                    cellspacing="0">
                    <thead>
                        <tr>
                            <th>PRODUCT ID</th>
                            <th>CATEGORY ID</th>
                            <th>NAME</th>
                            <th>IMAGE</th>
                            <th>QUANTITY</th>
                            <th>PRICE</th>
                            <th>EDIT</th>
                            <th>DELETE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

                        $fetch_query = "SELECT * FROM product";
                        $fetch_query_run = mysqli_query($connection, $fetch_query);

                        if (mysqli_num_rows($fetch_query_run) > 0) {
                            foreach ($fetch_query_run as $row) {
                                ?>
                                <tr>
                                    <td>
                                        <?php echo $row['prod_id'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['cat_id'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['prod_name'] ?>
                                    </td>
                                    <td>
                                        <img src="uploads/<?php echo $row['prod_image'] ?>" height="70" width="70" alt="">
                                    </td>
                                    <td>
                                        <?php echo $row['prod_quantity'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['prod_price'] ?>
                                    </td>
                                    <td>
                                        <a href="edit.php?id=<?php echo $row['prod_id']; ?>" class="btn btn-primary">EDIT</a>
                                    </td>
                                    <td>
                                        <form action="code.php" method="POST">
                                            <input type="hidden" name="user_id" value="<?php echo $row['prod_id']; ?>">
                                            <button type="submit" name="delete_btn" class="btn btn-danger">DELETE</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="8">No Record found</td>
                            </tr>
                            <?php
                        }

                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <a id="back-to-top" href="#" class="btn btn-light btn-lg back-to-top float-end mt-3" role="button">
        <i class="fas fa-chevron-up"></i></a>

</div>




<?php include ('includes/footer.php'); ?>