<?php include('dbconfig/dbconfig.php'); ?>
<?php include('includes/header.php'); ?>



<div class="container-fluid">
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-lg-6 mb-lg-0 mb-4">

        </div>
        <div class="col-lg-6">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end">

            </ul>
        </div>
    </div>


    <div class="card mt-3">

        <div class="card-header">
            <h4>Edit Product</h4>
        </div>

        <?php

        $id = $_GET['id'];
        $fetch_query = "SELECT * FROM product WHERE prod_id='$id'";
        $fetch_query_run = mysqli_query($connection, $fetch_query);

        if ($fetch_query_run) {
            foreach ($fetch_query_run as $row) {
                //;
        ?>

                <div class="card-body">

                    <form action="code.php" method="POST" enctype="multipart/form-data">

                        <div class="mb-3">
                            <label for="id" class="text-secondary">Edit product Id</label>
                            <input type="text" class="form-control " name="id" id="id" value="<?php echo $row['prod_id']; ?>" placeholder="Add Product" required readonly>
                        </div>

                        <div class="mb-3">
                            <label for="prod_name" class="text-secondary">Edit product Name</label>
                            <input type="text" class="form-control" name="prod_name" id="prod_name" value="<?php echo $row['prod_name']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="prod_image" class="text-secondary">Edit product Image</label>
                            <input class="form-control form-control-sm fs-5" name="prod_image" accept="image/jpg, image/jpeg, image/png" type="file" required>
                            <input type="hidden" name="prod_image_old" value="<?php echo $row['prod_image']; ?>" >
                            <img src="<?php echo "uploads/".$row['prod_image']; ?>" width="75" height="75" alt="image">
                        </div>

                        <div class="mb-3">
                            <label for="prod_quantity" class="text-secondary">Edit product Quantity</label>
                            <input type="number" class="form-control" name="prod_quantity" id="prod_quantity" value="<?php echo $row['prod_quantity']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="prod_price" class="text-secondary">Edit product Price</label>
                            <input type="number" class="form-control" name="prod_price" id="prod_price" value="<?php echo $row['prod_price']; ?>" required>
                        </div>

                        <div class="card-footer">
                            <button type="submit" name="update_btn" class="btn btn-primary float-start mt-4" data-bs-dismiss="modal">UPDATE</button>
                        </div>

                        <a href="product.php" button type="submit" name="btn_cancel" class="btn btn-danger float-end">CANCEL</button>
                            <a href="<?= $previous ?>"></a>
                    </form>
                </div>
        <?php
            }
        } else {
            echo "No record found";
        }

        ?>


    </div>

</div>




<?php include('includes/footer.php'); ?>