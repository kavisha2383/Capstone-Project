<?php include('dbconfig/dbconfig.php'); ?>
<?php include('includes/header.php'); ?>



<div class="container-fluid">
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-lg-6 mb-lg-0 mb-4">

        </div>
        <div class="col-lg-6">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end">
                
            </ul>
        </div>
    </div>

    <!-- <?php

            if (isset($_SESSION['status']) && $_SESSION['status'] != '') {

            ?>
        <div class="alert alert-success text-light alert-dismissible fade show mt-1" role="alert">
            <strong>heyy!</strong> <?php echo $_SESSION['status']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
        <?php
                //unset($_SESSION['status']);
            }
        ?> -->



    <div class="card mt-3">
        <div class="card-header">
            <h4> Customers Table</h4>
        </div>

        <div class="card-body pt-4 text-center">
            <div class="table-responsive">
                <table class="table table-striped datatable fs-6" style="width:100%" id="datatable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>CUSTOMER ID</th>
                            <th>FIRST NAME</th>
                            <th>LAST NAME</th>
                            <th>EMAIL ID</th>
                            <th>CONTACT NO</th>
                            <th>ADDRESS line 1</th>
                            <th>ADDRESS line 2</th>
                            <th>CITY</th>
                            <th>STATE</th>
                            <th>PINCODE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

                        $fetch_query = "SELECT * FROM customer";
                        $fetch_query_run = mysqli_query($connection, $fetch_query);

                        if (mysqli_num_rows($fetch_query_run) > 0) {
                            foreach ($fetch_query_run as $row) {
                        ?>
                                <tr>
                                    <td>
                                        <?php echo $row['customer_id'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['firstname'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['lastname'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['email'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['contact'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['add1'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['add2'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['city'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['state'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['pincode'] ?>
                                    </td>
                                    
                                    <!--<td>
                                        <form action="code.php" method="POST">
                                            <input type="hidden" name="customer_id" value="<?php echo $row['customer_id']; ?>">
                                            <button type="submit" name="customer_delete_btn" class="btn btn-danger">DELETE</button>
                                        </form>
                                    </td>-->
                                </tr>
                            <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="10">No Record found</td>
                            </tr>
                        <?php
                        }

                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <a id="back-to-top" href="#" class="btn btn-light btn-lg back-to-top float-end mt-3" role="button">
        <i class="fas fa-chevron-up"></i></a>

</div>





<?php include('includes/footer.php'); ?>