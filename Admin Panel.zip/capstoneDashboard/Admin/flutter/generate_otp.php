<?php
    $con=mysqli_connect("localhost","root","","capstone");
    return $con;

    if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact'])){
        $contact = $_POST['contact'];
        $otp = rand(1000, 9999);

        echo json_encode(array('success' => true, 'otp' => $otp));
        exit;
    }

    if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact']) && isset($_POST['otp'])){
        $contact = $_POST['contact'];
        $otp = $_POST['otp'];

        if ($otp == $stored_otp){
            echo json_encode(array('success' => true));
        }
        else{
            echo json_encode(array('success' => false, 'message' => 'OTP verification failed'));
        }
        exit;
    }

?>