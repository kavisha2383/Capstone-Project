<?php

header("Access-Control-Allow-Origin: *"); // Allow requests from any origin
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); // Allow the specified HTTP methods
header("Access-Control-Allow-Headers: Content-Type"); // Allow the specified headers

$connection = mysqli_connect("localhost","root","","capstone");

if($connection === false){
    die("Error: Unable to connect to database. " . mysqli_connect_error());
}

$sql = "SELECT * FROM advertisement";
$result = mysqli_query($connection, $sql);

if($result === false){
    die("Error: Unable to fetch data. " . mysqli_error($connection));
}

$data = array();

while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

header('Content-Type: application/json');
echo json_encode($data);

mysqli_close($connection);

?>