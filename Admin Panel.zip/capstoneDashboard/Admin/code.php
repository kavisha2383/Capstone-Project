<?php include('dbconfig/dbconfig.php'); ?>

<?php
session_start();

//save button
$connection = mysqli_connect("localhost", "root", "", "capstone");

//ADD PRODUCT
if (isset($_POST['add_save'])) {
    
    $category_id = $_POST['cat_id'];
    $name = $_POST['prod_name'];
    $quantity = $_POST['prod_quantity'];
    $price = $_POST['prod_price'];

    $image = $_FILES['prod_image']['name'];
    $image_tmp = $_FILES['prod_image']['tmp_name'];
    $path = "uploads/";

    $image_ext = pathinfo($image, PATHINFO_EXTENSION);
    $filename = time() . '.' . $image_ext;

    $insert_query = "INSERT INTO product(cat_id,prod_name,prod_image,prod_quantity,prod_price) VALUES ('$category_id','$name','$filename','$quantity','$price')";
    $insert_query_run = mysqli_query($connection, $insert_query);

    if ($insert_query_run) {
        move_uploaded_file($_FILES['prod_image']['tmp_name'], $path . '/' . $filename);
        $_SESSION['status'] = "DATA INSERTED SUCCESSFULLY";
        $_SESSION['status_code'] = 'success';
        header('location: product.php');
    } else {
        $_SESSION['status'] = "DATA NOT INSERTED SUCCESSFULLY";
        $_SESSION['status_code'] = 'error';
        header('location: insert.php');
    }
}

//EDIT PRODUCT

if (isset($_POST['update_btn'])) {
    $id = $_POST['id'];

    $name = $_POST['prod_name'];
    $quantity = $_POST['prod_quantity'];
    $price = $_POST['prod_price'];
    $new_image = $_FILES['prod_image']['name'];
    $old_image = $_POST['prod_image_old'];

    // Prepare update query with placeholders
    $update_query = "UPDATE product SET prod_name = ?, prod_image = ?, prod_quantity = ?, prod_price = ? WHERE prod_id = ?";
    $stmt = mysqli_prepare($connection, $update_query);

    if ($stmt) {
        // Bind parameters to statement
        mysqli_stmt_bind_param($stmt, "ssiii", $name, $new_image, $quantity, $price, $id);

        // Execute the statement
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            // Check if a new image is uploaded
            if ($new_image != '') {
                // Move uploaded file
                $target_dir = "uploads/";
                $target_file = $target_dir . basename($new_image);
                if (move_uploaded_file($_FILES['prod_image']['tmp_name'], $target_file)) {
                    unlink('uploads/' . $old_image);
                } else {
                    $_SESSION['status'] = "Error moving uploaded file";
                    header('location: product.php');
                    exit();
                }
            }
            $_SESSION['status'] = "Product updated successfully";
            header('location: product.php');
        } else {
            $_SESSION['status'] = "Error updating product: " . mysqli_error($connection);
            header('location: product.php');
        }
    } else {
        $_SESSION['status'] = "Error preparing statement: " . mysqli_error($connection);
        header('location: product.php');
    }

    // Close statement
    mysqli_stmt_close($stmt);
} else {
    $_SESSION['status'] = "Update button not clicked";
    header('location: product.php');
}

//DELETE BUTTON
if (isset($_POST['delete_btn'])) {
    $id = $_POST['user_id'];
    $delete_query = "DELETE FROM product WHERE prod_id='$id'";
    $delete_query_run = mysqli_query($connection, $delete_query);

    if ($delete_query_run) {
        move_uploaded_file($_FILES['prod_image']['tmp_name'], $path . '/' . $filename);
        $_SESSION['status'] = "DATA DELETED SUCCESSFULLY";
        $_SESSION['status_code'] = 'success';
        header('location: product.php');
    } else {
        $_SESSION['status'] = "DATA DELETION FAILED";
        $_SESSION['status_code'] = 'error';
        header('location: product.php');
    }
}


//ADD CATEGORY

if (isset($_POST['save_cat'])) {

    $cat_name = $_POST['cat_name'];

    $cat_image = $_FILES['cat_image']['name'];
    $cat_image_tmp = $_FILES['cat_image']['tmp_name'];
    $path = "uploads/";


    $image_ext = pathinfo($cat_image, PATHINFO_EXTENSION);
    $filename = time() . '.' . $image_ext;

    $insert_cat_query = "INSERT INTO category(cat_name,cat_image) VALUES ('$cat_name','$filename')";
    $insert_cat_query_run = mysqli_query($connection, $insert_cat_query);

    if ($insert_cat_query_run) {
        move_uploaded_file($_FILES['cat_image']['tmp_name'], $path . '/' . $filename);
        $_SESSION['status'] = "DATA INSERTED SUCCESSFULLY";
        header('location: categories.php');
    } else {
        $_SESSION['status'] = "DATA NOT INSERTED SUCCESSFULLY";
        header('location: category_insert.php');
    }
}


//EDIT CATEGORY

if (isset($_POST['cat_update_btn'])) {
    $id = $_POST['id'];

    $name = $_POST['cat_name'];

    $new_image = $_FILES['cat_image']['name'];
    $old_image = $_POST['cat_image_old'];

    // Prepare update query with placeholders
    $update_query = "UPDATE category SET cat_name = ?, cat_image = ? WHERE cat_id = ?";
    $stmt = mysqli_prepare($connection, $update_query);

    if ($stmt) {
        // Bind parameters to statement
        mysqli_stmt_bind_param($stmt, "ssiii", $name, $new_image, $id);

        // Execute the statement
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            // Check if a new image is uploaded
            if ($new_image != '') {
                // Move uploaded file
                $target_dir = "uploads/";
                $target_file = $target_dir . basename($new_image);
                if (move_uploaded_file($_FILES['cat_image']['tmp_name'], $target_file)) {
                    unlink('uploads/' . $old_image);
                } else {
                    $_SESSION['status'] = "Error moving uploaded file";
                    header('location: categories.php');
                    exit();
                }
            }
            $_SESSION['status'] = "Product updated successfully";
            header('location: categories.php');
        } else {
            $_SESSION['status'] = "Error updating product: " . mysqli_error($connection);
            header('location: categories.php');
        }
    } else {
        $_SESSION['status'] = "Error preparing statement: " . mysqli_error($connection);
        header('location: categories.php');
    }

    // Close statement
    mysqli_stmt_close($stmt);
} else {
    $_SESSION['status'] = "Update button not clicked";
    header('location: categories.php');
}


//DELETE CATEGORY
if (isset($_POST['cat_delete_btn'])) {
    $id = $_POST['cat_user_id'];
    $delete_query = "DELETE FROM category WHERE cat_id='$id'";
    $delete_query_run = mysqli_query($connection, $delete_query);

    if ($delete_query_run) {
        move_uploaded_file($_FILES['cat_image']['tmp_name'], $path . '/' . $filename);
        $_SESSION['status'] = "DATA DELETED SUCCESSFULLY";
        $_SESSION['status_code'] = 'success';
        header('location: categories.php');
    } else {
        $_SESSION['status'] = "DATA DELETION FAILED";
        $_SESSION['status_code'] = 'error';
        header('location: insert.php');
    }
}

//ADD ADVERTISEMENT

if (isset($_POST['save_ad'])) {

    $title = $_POST['title'];
    $description = $_POST['description'];

    $banner = $_FILES['banner']['name'];
    $image_tmp = $_FILES['banner']['tmp_name'];
    $path = "uploads/";


    $image_ext = pathinfo($banner, PATHINFO_EXTENSION);
    $filename = time() . '.' . $image_ext;

    $insert_ad_query = "INSERT INTO advertisement(banner,title,description) VALUES ('$filename','$title','$description')";
    $insert_ad_query_run = mysqli_query($connection, $insert_ad_query);

    if ($insert_ad_query_run) {
        move_uploaded_file($_FILES['banner']['tmp_name'], $path . '/' . $filename);
        $_SESSION['status'] = "DATA INSERTED SUCCESSFULLY";
        header('location: advertise.php');
    } else {
        $_SESSION['status'] = "DATA NOT INSERTED SUCCESSFULLY";
        header('location: advertise_insert.php');
    }
}

//EDIT ADVERTISEMENT

if (isset($_POST['ad_update_btn'])) {

    $id = $_POST['id'];

    $title = $_POST['title'];
    $description = $_POST['description'];

    $image = $_FILES['banner']['name'];
    $image_tmp = $_FILES = ['banner']['tmp_name'];
    $path = 'uploads/';

    $image_ext = pathinfo($image, PATHINFO_EXTENSION);
    $filename = time() . '.' . $image_ext;

    $update_query = "UPDATE advertisement SET banner='$filename', title='$title', description='$description' WHERE ad_id='$id'";
    $update_query_run = mysqli_query($connection, $update_query);

    if ($update_query_run) {
        move_uploaded_file($_FILES['cat_image']['tmp_name'], $path . '/' . $filename);
        $_SESSION['status'] = "DATA UPDATED SUCCESSFULLY";
        $_SESSION['status_code'] = 'success';
        header('location: advertise.php');
    } else {
        $_SESSION['status'] = "UPDATION FAILED";
        $_SESSION['status_code'] = 'error';
        header('location: advertise_insert.php');
    }
}

//DELETE ADVERTISEMENT
if (isset($_POST['ad_delete_btn'])) {
    $id = $_POST['ad_user_id'];
    $delete_query = "DELETE FROM advertisement WHERE ad_id='$id'";
    $delete_query_run = mysqli_query($connection, $delete_query);

    if ($delete_query_run) {
        move_uploaded_file($_FILES['banner']['tmp_name'], $path . '/' . $filename);
        $_SESSION['status'] = "DATA DELETED SUCCESSFULLY";
        $_SESSION['status_code'] = 'success';
        header('location: advertise.php');
    } else {
        $_SESSION['status'] = "DATA DELETION FAILED";
        $_SESSION['status_code'] = 'error';
        header('location: advertise_insert.php');
    }
}

//Add Offers

if (isset($_POST['save_offer'])) {
    
    $prod_id = $_POST['prod_id'];
    $name = $_POST['offer_name'];
    $quantity = $_POST['offer_quantity'];
    $price = $_POST['offer_price'];
    $discount = $_POST['disc_amt'];
    $startdate = $_POST['start_date'];
    $enddate = $_POST['end_date'];

    $image = $_FILES['offer_image']['name'];
    $image_tmp = $_FILES['offer_image']['tmp_name'];
    $path = "uploads/";

    $image_ext = pathinfo($image, PATHINFO_EXTENSION);
    $filename = time() . '.' . $image_ext;

    $insert_query = "INSERT INTO offers(prod_id,offer_name,offer_image,offer_quantity,offer_price,disc_amt,start_date,end_date) VALUES ('$prod_id','$name','$filename','$quantity','$price','$discount','$startdate','$enddate')";
    $insert_query_run = mysqli_query($connection, $insert_query);

    if ($insert_query_run) {
        move_uploaded_file($_FILES['offer_image']['tmp_name'], $path . '/' . $filename);
        $_SESSION['status'] = "DATA INSERTED SUCCESSFULLY";
        $_SESSION['status_code'] = 'success';
        header('location: offers.php');
    } else {
        $_SESSION['status'] = "DATA NOT INSERTED SUCCESSFULLY";
        $_SESSION['status_code'] = 'error';
        header('location: insert.php');
    }
}


//Delete offers

if (isset($_POST['offer_delete_btn'])) {
    $id = $_POST['offer_user_id'];
    $delete_query = "DELETE FROM offers WHERE offer_id='$id'";
    $delete_query_run = mysqli_query($connection, $delete_query);

    if ($delete_query_run) {
        move_uploaded_file($_FILES['banner']['tmp_name'], $path . '/' . $filename);
        $_SESSION['status'] = "DATA DELETED SUCCESSFULLY";
        $_SESSION['status_code'] = 'success';
        header('location: offers.php');
    } else {
        $_SESSION['status'] = "DATA DELETION FAILED";
        $_SESSION['status_code'] = 'error';
        header('location: offer_insert.php');
    }
}
?>

<?php

//product cancel button
if (isset($_POST['btn_cancel']))

    $privious = $_POST['product.php'];

?>